

It's not a usual power point file as you can tell, in order to check our presentation please execute the "SGBD_Gmao.exe" file.

To enjoy the full experience of the presentation, make sure to click the left mouse button and for an every click at least two seconds on hold.

Use the right mouse button to navigate in the drawn Diagram.

Enjoy.